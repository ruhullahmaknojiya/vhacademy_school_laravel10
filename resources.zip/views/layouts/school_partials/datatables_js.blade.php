<!-- Datatables -->
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.0.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.print.min.js"></script>
{{--<script src="{{ asset('js/buttons.bootstrap4.min.js') }}"></script>--}}
{{--<script src="{{ asset('js/buttons.colVis.min.js') }}"></script>--}}
{{--<script src="{{ asset('js/buttons.html5.min.js') }}"></script>--}}
{{--<script src="{{ asset('js/buttons.print.min.js') }}"></script>--}}
{{--<script src="{{ asset('js/dataTables.bootstrap4.min.js') }}"></script>--}}
{{--<script src="{{ asset('js/dataTables.buttons.min.js') }}"></script>--}}
{{--<script src="{{ asset('js/dataTables.responsive.min.js') }}"></script>--}}
{{--<script src="{{ asset('js/jquery.dataTables.min.js') }}"></script>--}}
{{--<script src="{{ asset('js/responsive.bootstrap4.min.js') }}"></script>--}}

