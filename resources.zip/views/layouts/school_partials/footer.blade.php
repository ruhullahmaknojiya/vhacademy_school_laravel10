<footer class="main-footer">
   <center> <strong>Copyright &copy; 2024 <a href="#">VHM Academy</a>.</strong>
    All rights reserved.
   </center>
</footer>
